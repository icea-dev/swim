OGC(r) GeoSPARQL schema - ReadMe.txt
========================================

OGC GeoSPARQL - A Geographic Query Language for RDF Data

More information may be found at
 http://www.opengeospatial.org/standards/geosparql

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2012-09-10  Simon Cox
  + v1.0: updated geosparql/1.0 with 1.0.1 corrections
  + v1.0: add geosparql 1.0.1 ontology sf/1.0/simple_features_geometries.rdf
  + v1.0: add geosparql 1.0.1 ontology gml/3.2.1/gml_32_geometries.rdf

2012-06-12  Kevin Stegemoller
  + v1.0.0: added geosparql/1.0 - OGC 11-052r4

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2012 Open Geospatial Consortium.

-----------------------------------------------------------------------
