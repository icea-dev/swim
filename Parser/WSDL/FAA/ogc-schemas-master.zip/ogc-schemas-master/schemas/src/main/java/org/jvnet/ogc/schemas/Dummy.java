package org.jvnet.ogc.schemas;

public class Dummy {}