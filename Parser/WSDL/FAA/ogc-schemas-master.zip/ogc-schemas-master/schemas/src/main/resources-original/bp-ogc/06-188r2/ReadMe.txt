GML 3.2 implementation of Discrete Coverage XML schemas in 06-188r2 (cv 0.2.2_gml32)

OGC Document ID:  06-188r2 with change request 08-130
Document Version: 0.2.2
Document type:    OGC Best Practice
Date Published:   2008-08-25
Date Voted:       2008-11-02 - Electronic Vote
Online Reference: http://www.opengeospatial.org/standards/bp

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/policies/ .

Copyright (c) 2007 Open Geospatial Consortium, Inc. All Rights Reserved.
